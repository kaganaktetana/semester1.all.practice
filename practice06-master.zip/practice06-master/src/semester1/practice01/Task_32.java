package semester1.practice01;

public class Task_32 {
    public static void main(String[] args) {
    System.out.println("Периметр кімнати (м):");
    System.out.println((6 + 4) * 2);
    System.out.println("Площа кімнати (кв. м):");
    System.out.println(6 * 4);
}
}
