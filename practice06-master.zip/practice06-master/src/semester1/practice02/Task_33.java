package semester1.practice02;
public class Task_33 {
    public static void main(String[] args) {
        double a = 3.0;
        double b = 4.0;
        double c = Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
        System.out.println("Катети: " + a + " та " + b + ". Гіпотенуза: " + c);
    }
}