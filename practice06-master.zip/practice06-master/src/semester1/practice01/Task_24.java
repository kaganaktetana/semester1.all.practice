package semester1.practice01;

public class Task_24 {
    public static void main(String[] args) {
    System.out.println("Java");
    System.out.println("\tце");
    System.out.println("\t\tпросто");
    System.out.println("\t\t\t\tта");
    System.out.println("\t\t\t\t\tпотужно!");
}
}
